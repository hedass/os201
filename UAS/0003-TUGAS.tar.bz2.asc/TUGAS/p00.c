/*
// Tambahkan di sini nama para kontributor (akunGitHub)
// Harap UPDATE tanggal revisi!
// Tue Jun  9 17:46:47 WIB 2020
 */

#include "share.h"
char*    akunGitHub = "yogahmad";
int      delay      = 3;
int      boss       = BOSS;

