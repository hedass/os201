/*
// Tambahkan di sini nama para kontributor (akunGitHub)
// Harap UPDATE tanggal revisi!
// Tue Jun  9 17:46:47 WIB 2020
 */

#include "share.h"
char*    akunGitHub = "hedass";
int      delay      = 1;
int      boss       = NOTBOSS;

