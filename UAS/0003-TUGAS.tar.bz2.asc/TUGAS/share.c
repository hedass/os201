/*
// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:58:13 WIB 2020
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
 */

#include     "share.h"
char*        progs[]={P01, P02, P03, P04, P05, P06, P07};
char         tmpStr[256]={};
extern char* akunGitHub;
extern int   delay;
extern int   boss;
myshare*     mymap;

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:58:13 WIB 2020
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
void init(int isboss, int argc, char* argv[]) {
    if (isboss == BOSS) {
        int ssize=sizeof(myshare);
        int fd   =open(SHAREMEM, MYFLAGS, CHMOD);
        fchmod   (fd, CHMOD);
        ftruncate(fd, ssize);
        mymap=mmap(NULL, ssize, MYPROTECTION, MYVISIBILITY, fd, 0);
        close(fd);
        mymap->state = OPEN;
        if (argc > 1) {
            puts("ShareMemory is OPEN, BYE BYE ==== ====");
            exit(-1);
        }
        sem_init (&(mymap->mutex), 1, MUTEX); // lihat manual sem_init()!
        for (int i = 0; i < 7; ++i) {
            int child_pid = fork();
            if(child_pid == 0)
                execl(progs[i], progs[i], NULL);
        }
    } else {
        sleep(delay);
        if( access(SHAREMEM, F_OK ) == -1 ) {
            printf("No \"%s\" file.\n", SHAREMEM);
            exit(-1);
        }
        int fd=open(SHAREMEM, O_RDWR, CHMOD);
        int ssize=sizeof(myshare);
        mymap=mmap(NULL, ssize, MYPROTECTION, MYVISIBILITY, fd, 0);
        close(fd);
    }
}

// Contributor: cbkadal
// Tue Jun  9 17:46:47 WIB 2020
void myPrint(char* str1, char* str2) {
    printf("%s[%s]\n", str1, str2);
    fflush(NULL);
}

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Tue Jun  30 00:06:36 WIB 2020
// Mon Jun 29 22:58:13 WIB 2020
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
int getEntry(char* akunGitHub) {
    int entry = -1;
    sem_wait (&(mymap->mutex));
    for(int i = 0; i < mymap->entry; i++){
        if(strcmp(mymap->progs[i].akun, akunGitHub) == 0){
            entry = i;
            break;
        }
    }
    if(entry == -1){
        entry = mymap->entry++;
    }
    mymap->mutexctr++;
    mymap->progs[entry].stamp++;
    sem_post (&(mymap->mutex));
    return entry;
}

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:58:13 WIB 2020
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
void display(int entry) {
    sem_wait (&(mymap->mutex));
    mymap->mutexctr++;
    mymap->progs[entry].stamp++;
    sprintf(tmpStr, "progs[%02d] TIME[%02d] MUTEX[%02d] MMAP[%s] ", entry, mymap->mutexctr,mymap->progs[entry].stamp, mymap->state == OPEN ? "OPEN" : "CLOSED");
    for (int i = 0; i < mymap->entry; ++i)  {
        sprintf(tmpStr, "%s[%s]", tmpStr, mymap->progs[i].akun);
    }
    myPrint(akunGitHub, tmpStr);
    sem_post (&(mymap->mutex));
}

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:58:13 WIB 2020
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
void putInfo(char* akun, int entry) {
    sem_wait (&(mymap->mutex));
    mymap->progs[entry].stamp++;
    mymap->mutexctr++;
    sprintf(mymap->progs[entry].akun, "%s", akun);
    sem_post (&(mymap->mutex));
}

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
void checkOpen(void) {
    if(mymap->state == CLOSED)  {
        puts("ShareMemory is NOT OPEN, BYE BYE ==== ====");
        exit(-1);
    }
}

// Contributors: yogahmad, hedass, lepiku, codefire53, zafirr31, iqrar99, lepiku, finishal
// Mon Jun 29 22:55:31 WIB 2020
// Tue Jun  9 17:46:47 WIB 2020
void myWait(int boss, int entry) {
    if(boss == BOSS){
        int status = 0;
        while (wait(&status) > 0);
        mymap->state = CLOSED;
    }
}

// Contributor: cbkadal
// Tue Jun  9 17:46:47 WIB 2020
int main(int argc, char* argv[]) {
    sprintf(tmpStr, "START PID[%d] PPID[%d]", getpid(), getppid());
    myPrint(akunGitHub, tmpStr);
    init(boss, argc, argv);
    checkOpen();
    sleep  (delay);
    int entry = getEntry(akunGitHub);
    sleep  (delay);
    display(entry);
    sleep  (delay);
    putInfo(akunGitHub, entry);
    sleep  (delay);
    display(entry);
    myWait (boss, entry);
    myPrint(akunGitHub, "BYEBYE =====  ===== =====");
}
